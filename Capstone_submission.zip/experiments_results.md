# Experiments: 5-fold CV comparison

## LogisticRegression
- Fold scores: [1.0, 0.9666666666666667, 0.9, 1.0, 0.9]
- Mean accuracy: 0.9533
- Std accuracy: 0.0452

## RandomForest
- Fold scores: [0.9666666666666667, 0.9666666666666667, 0.9333333333333333, 0.9666666666666667, 0.9]
- Mean accuracy: 0.9467
- Std accuracy: 0.0267

## SVC
- Fold scores: [1.0, 0.9666666666666667, 0.9, 1.0, 0.9333333333333333]
- Mean accuracy: 0.9600
- Std accuracy: 0.0389

